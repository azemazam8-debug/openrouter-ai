# AI OpenRouter — Vercel

Versi ini dibuat agar bisa di-deploy sebagai web app tanpa Termux.

## Deploy dari HP

1. Buat akun Vercel.
2. Upload folder/project ini sebagai project baru.
3. Di Project Settings → Environment Variables, tambahkan:
   - `OPENROUTER_API_KEY` = API key OpenRouter kamu
   - `OPENROUTER_MODEL` = `openai/gpt-oss-20b` (atau model OpenRouter lain yang kamu pilih)
4. Deploy / Redeploy.
5. Buka URL Vercel dari Chrome Android.

## Keamanan

API key hanya berada di environment variable server. Jangan menaruh API key di `public/index.html`.

## Catatan

Teks pengguna dikirim dalam JSON body. HTTP headers tidak menerima teks bebas/emoji, sehingga project ini menghindari error:
"String contains non ISO-8859-1 code point".
