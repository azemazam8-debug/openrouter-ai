export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method Not Allowed" });
  }

  const apiKey = process.env.OPENROUTER_API_KEY;
  const model = process.env.OPENROUTER_MODEL || "openai/gpt-oss-20b";

  if (!apiKey) {
    return res.status(500).json({ error: "OPENROUTER_API_KEY belum diset di Vercel." });
  }

  try {
    const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];

    if (!messages.length) {
      return res.status(400).json({ error: "Pesan kosong." });
    }

    const cleanMessages = messages.map((m) => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content ?? "")
    }));

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model,
        messages: cleanMessages,
        temperature: 0.7
      })
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json({
        error: data?.error?.message || "OpenRouter request gagal."
      });
    }

    return res.status(200).json({
      answer: data?.choices?.[0]?.message?.content || "AI tidak mengembalikan jawaban.",
      model
    });
  } catch (error) {
    return res.status(500).json({
      error: error?.message || "Server error."
    });
  }
}
